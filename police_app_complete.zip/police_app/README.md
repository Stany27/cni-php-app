# Application de Gestion du Personnel de la Police Camerounaise

## 🚀 Vue d'ensemble

Cette application web et mobile responsive a été conçue pour moderniser et optimiser la gestion du personnel de la Police camerounaise. Elle offre une solution complète avec authentification multi-rôles, interfaces utilisateur intuitives, et fonctionnalités avancées de gestion administrative.

## ✨ Fonctionnalités Principales

### 🔐 Authentification et Sécurité
- **Authentification multi-facteurs (2FA/MFA)**
- **Gestion des rôles** : DGSN, DRH, Délégués régionaux, Superviseurs, Policiers
- **Sessions sécurisées** avec protection CSRF, XSS, et injection SQL
- **Hashage des mots de passe** avec bcrypt
- **Journalisation complète** des actions

### 👮‍♂️ Interface Policier
- Connexion sécurisée avec authentification 2FA
- Demande de production de carte professionnelle
- Création et suivi de demandes (affectation, mutation, promotion, congé, formation, sanctions, notation)
- Consultation du dossier personnel
- Réception de notifications en temps réel
- Téléchargement de formulaires et documents administratifs
- Impression du récapitulatif de carrière
- Gestion du profil personnel

### 🏛️ Interface Administration
- **Gestion complète du personnel** (ajout, modification, consultation)
- **Production des cartes professionnelles**
- **Gestion des carrières, promotions, formations**
- **Traitement des demandes** (approbation/rejet)
- **Génération de statistiques** avancées
- **Rapports PDF** téléchargeables
- **Recherche filtrée** multi-critères

### 👑 Interface Super Administrateur (DGSN)
- **Accès complet** au système
- **Gestion des utilisateurs** administrateurs
- **Statistiques globales** et rapports périodiques
- **Configuration système**
- **Sauvegarde et restauration** des données

### 📊 Tableau de Bord Dynamique
- **Statistiques en temps réel** avec graphiques interactifs
- **Notifications push** et par email
- **Calendrier intégré** pour la gestion des événements
- **Widgets personnalisables**

## 🛠️ Technologies Utilisées

### Backend
- **PHP 8.x** avec architecture MVC
- **MySQL 8.x** pour la base de données
- **Composer** pour la gestion des dépendances
- **Twig** pour les templates
- **PHPMailer** pour l'envoi d'emails
- **JWT** pour l'authentification
- **DOMPDF** pour la génération de PDF

### Frontend
- **HTML5, CSS3, JavaScript**
- **Bootstrap 5** pour le design responsive
- **Angular 16** pour les composants dynamiques
- **jQuery** pour les interactions AJAX
- **Chart.js** pour les graphiques
- **DataTables** pour les tableaux avancés
- **SweetAlert2** pour les notifications

### Sécurité
- **Protection CSRF/XSS/SQL Injection**
- **Validation côté client et serveur**
- **Chiffrement des données sensibles**
- **Audit trail complet**
- **ReCaptcha** anti-bot

## 📋 Prérequis

- **Windows 10** (64-bit)
- **XAMPP 8.2.x** ou supérieur
- **4 GB RAM** minimum (8 GB recommandé)
- **2 GB** d'espace disque libre
- **Connexion internet** pour l'installation

## 🚀 Installation Rapide

### 1. Installation de XAMPP
```bash
1. Téléchargez XAMPP depuis https://www.apachefriends.org/
2. Installez XAMPP dans C:\xampp
3. Démarrez Apache et MySQL depuis le Control Panel
```

### 2. Installation de l'Application
```bash
1. Extrayez police_app.zip dans C:\xampp\htdocs\
2. Ouvrez l'invite de commande dans le dossier du projet
3. Exécutez : composer install
4. Exécutez : npm install
```

### 3. Configuration de la Base de Données
```bash
1. Ouvrez phpMyAdmin (http://localhost/phpmyadmin)
2. Créez une base de données "police_db"
3. Importez le fichier database.sql
4. Copiez .env.example vers .env et configurez les paramètres
```

### 4. Accès à l'Application
```
URL : http://localhost/police_app/public/

Comptes de test :
- DGSN : dgsn_admin / password123
- DRH : drh_admin / password123
- Policier : policier_1 / password123
```

## 📖 Documentation Complète

- **Guide d'installation détaillé** : `etapes_execution.md`
- **Architecture technique** : `architecture_conception.md`
- **Fonctionnalités modernes** : `fonctionnalites_modernes.md`
- **Suivi des tâches** : `todo.md`

## 🏗️ Structure du Projet

```
police_app/
├── app/
│   ├── controllers/     # Contrôleurs MVC
│   ├── models/         # Modèles de données
│   ├── views/          # Templates Twig
│   ├── config/         # Configuration
│   └── core/           # Classes de base
├── public/
│   ├── css/           # Feuilles de style
│   ├── js/            # Scripts JavaScript
│   ├── img/           # Images
│   ├── uploads/       # Fichiers uploadés
│   └── index.php      # Point d'entrée
├── vendor/            # Dépendances Composer
├── docs/              # Documentation
├── tests/             # Tests unitaires
├── .env.example       # Configuration d'environnement
├── composer.json      # Dépendances PHP
└── package.json       # Dépendances Node.js
```

## 🔧 Configuration

### Variables d'Environnement (.env)
```env
# Base de données
DB_HOST=localhost
DB_NAME=police_db
DB_USER=root
DB_PASS=

# Application
APP_NAME="Gestion Personnel Police Camerounaise"
APP_ENV=development
APP_DEBUG=true
APP_URL=http://localhost/police_app

# Email
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=votre-email@gmail.com
MAIL_PASSWORD=votre-mot-de-passe-app

# Sécurité
JWT_SECRET=votre-cle-secrete
CSRF_TOKEN_EXPIRE=3600
```

## 🚀 Déploiement en Production

### 1. Préparation
```bash
1. Configurez APP_ENV=production dans .env
2. Désactivez APP_DEBUG=false
3. Configurez des mots de passe forts
4. Optimisez les assets (CSS/JS)
```

### 2. Upload sur Serveur
```bash
1. Uploadez tous les fichiers via FTP/SFTP
2. Configurez le serveur web pour pointer vers /public/
3. Configurez SSL avec Let's Encrypt
4. Configurez les sauvegardes automatiques
```

## 🔒 Sécurité

### Mesures Implémentées
- ✅ **Hashage bcrypt** des mots de passe
- ✅ **Protection CSRF** avec tokens
- ✅ **Validation XSS** de toutes les entrées
- ✅ **Requêtes préparées** contre l'injection SQL
- ✅ **Sessions sécurisées** avec expiration
- ✅ **Journalisation** des actions sensibles
- ✅ **Limitation** des tentatives de connexion
- ✅ **Headers de sécurité** HTTP

### Recommandations
- Changez tous les mots de passe par défaut
- Configurez SSL/HTTPS en production
- Effectuez des sauvegardes régulières
- Maintenez le système à jour

## 📊 Fonctionnalités Avancées

### Intelligence Artificielle
- **Analyse prédictive** des besoins en personnel
- **Détection d'anomalies** automatique
- **Recommandations** basées sur l'IA
- **Analyse de sentiment** du personnel

### Mobilité
- **Progressive Web App (PWA)**
- **Mode hors-ligne**
- **Géolocalisation** des agents
- **Notifications push**

### Intégrations
- **API RESTful** documentée
- **Webhooks** pour les systèmes tiers
- **Single Sign-On (SSO)**
- **Intégration cloud** (AWS, Google Drive)

## 🆘 Support et Dépannage

### Problèmes Courants

**Apache ne démarre pas**
```bash
- Vérifiez que le port 80 n'est pas utilisé
- Désactivez IIS si installé
- Consultez les logs Apache
```

**Erreur de connexion MySQL**
```bash
- Vérifiez que MySQL est démarré
- Contrôlez les paramètres dans .env
- Testez la connexion dans phpMyAdmin
```

**Page blanche**
```bash
- Activez l'affichage des erreurs PHP
- Vérifiez les logs d'erreur
- Contrôlez les permissions des fichiers
```

### Logs
- **Apache** : `C:\xampp\apache\logs\error.log`
- **MySQL** : `C:\xampp\mysql\data\mysql_error.log`
- **Application** : `police_app/logs/app.log`

## 🤝 Contribution

Pour contribuer au projet :
1. Forkez le repository
2. Créez une branche feature
3. Committez vos changements
4. Poussez vers la branche
5. Ouvrez une Pull Request

## 📄 Licence

Ce projet est sous licence MIT. Voir le fichier `LICENSE` pour plus de détails.

## 📞 Contact

- **Email** : support@police-app.cm
- **Téléphone** : +237 XXX XXX XXX
- **Documentation** : https://docs.police-app.cm

## 🙏 Remerciements

Développé avec ❤️ par **Manus AI** pour moderniser la gestion du personnel de la Police camerounaise.

---

**Version** : 1.0.0  
**Dernière mise à jour** : Janvier 2025  
**Compatibilité** : PHP 8.x, MySQL 8.x, Windows 10+


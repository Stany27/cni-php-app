<?php

// Démarrer la session
session_start();

// Définir le fuseau horaire
date_default_timezone_set('Africa/Douala');

// Autoloader Composer
require_once __DIR__ . '/../vendor/autoload.php';

// Charger les variables d'environnement
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Configuration des erreurs selon l'environnement
if ($_ENV['APP_ENV'] === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Configuration de sécurité des sessions
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
ini_set('session.use_strict_mode', 1);

// Headers de sécurité
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Configuration CORS pour les requêtes AJAX
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');
}

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    }
    exit(0);
}

use Core\Router;

// Initialiser le routeur
$router = new Router();

// Routes d'authentification
$router->get('/', 'AuthController@showLogin');
$router->get('/login', 'AuthController@showLogin');
$router->post('/login', 'AuthController@login');
$router->get('/logout', 'AuthController@logout');
$router->get('/register', 'AuthController@showRegister');
$router->post('/register', 'AuthController@register');
$router->get('/forgot-password', 'AuthController@showForgotPassword');
$router->post('/forgot-password', 'AuthController@forgotPassword');
$router->get('/reset-password', 'AuthController@showResetPassword');
$router->post('/reset-password', 'AuthController@resetPassword');

// Routes du tableau de bord
$router->get('/dashboard', 'DashboardController@index');
$router->get('/admin/dashboard', 'DashboardController@index');
$router->get('/supervisor/dashboard', 'DashboardController@index');
$router->get('/policier/dashboard', 'DashboardController@index');

// API pour les statistiques
$router->get('/api/stats', 'DashboardController@getStats');
$router->post('/api/notifications/mark-read', 'DashboardController@markNotificationAsRead');
$router->get('/api/export/stats', 'DashboardController@exportStats');

// Routes de gestion des policiers
$router->get('/policiers', 'PolicierController@index');
$router->get('/policier/create', 'PolicierController@create');
$router->post('/policier/create', 'PolicierController@create');
$router->get('/policier/{id}', 'PolicierController@show');
$router->get('/policier/{id}/edit', 'PolicierController@edit');
$router->post('/policier/{id}/edit', 'PolicierController@edit');
$router->post('/policier/{id}/delete', 'PolicierController@delete');
$router->get('/policier/profile', 'PolicierController@profile');
$router->post('/policier/profile', 'PolicierController@profile');

// API pour la recherche de policiers
$router->get('/api/policiers/search', 'PolicierController@search');
$router->get('/api/policiers/export', 'PolicierController@exportList');

// Routes de gestion des demandes
$router->get('/demandes', 'DemandeController@index');
$router->get('/demande/create', 'DemandeController@create');
$router->post('/demande/create', 'DemandeController@create');
$router->get('/demande/{id}', 'DemandeController@show');
$router->post('/demande/{id}/approve', 'DemandeController@approve');
$router->post('/demande/{id}/reject', 'DemandeController@reject');
$router->get('/mes-demandes', 'DemandeController@myDemandes');

// API pour les demandes
$router->get('/api/demandes/search', 'DemandeController@search');
$router->get('/api/demandes/export', 'DemandeController@exportList');

// Routes de gestion des cartes professionnelles
$router->get('/cartes', 'CarteController@index');
$router->get('/carte/create', 'CarteController@create');
$router->post('/carte/create', 'CarteController@create');
$router->get('/carte/{id}', 'CarteController@show');
$router->post('/carte/{id}/produce', 'CarteController@produce');
$router->post('/carte/{id}/deliver', 'CarteController@deliver');
$router->get('/carte/{id}/print', 'CarteController@printCard');

// Routes d'administration
$router->get('/admin/users', 'AdminController@users');
$router->get('/admin/user/create', 'AdminController@createUser');
$router->post('/admin/user/create', 'AdminController@createUser');
$router->get('/admin/user/{id}/edit', 'AdminController@editUser');
$router->post('/admin/user/{id}/edit', 'AdminController@editUser');
$router->post('/admin/user/{id}/delete', 'AdminController@deleteUser');

// Routes de configuration système (DGSN seulement)
$router->get('/admin/config', 'AdminController@config');
$router->post('/admin/config', 'AdminController@updateConfig');
$router->get('/admin/logs', 'AdminController@logs');
$router->get('/admin/backup', 'AdminController@backup');
$router->post('/admin/backup/create', 'AdminController@createBackup');
$router->post('/admin/backup/restore', 'AdminController@restoreBackup');

// Routes pour les rapports
$router->get('/reports', 'ReportController@index');
$router->get('/report/personnel', 'ReportController@personnel');
$router->get('/report/demandes', 'ReportController@demandes');
$router->get('/report/activite', 'ReportController@activite');
$router->get('/report/custom', 'ReportController@custom');
$router->post('/report/generate', 'ReportController@generate');

// Routes pour les notifications
$router->get('/notifications', 'NotificationController@index');
$router->post('/notification/send', 'NotificationController@send');
$router->get('/api/notifications', 'NotificationController@getNotifications');
$router->post('/api/notification/{id}/read', 'NotificationController@markAsRead');

// Routes pour les documents
$router->get('/documents', 'DocumentController@index');
$router->get('/document/{id}/download', 'DocumentController@download');
$router->post('/document/upload', 'DocumentController@upload');
$router->post('/document/{id}/delete', 'DocumentController@delete');

// Routes pour les formulaires
$router->get('/formulaires', 'FormulaireController@index');
$router->get('/formulaire/{type}', 'FormulaireController@show');
$router->get('/formulaire/{type}/download', 'FormulaireController@download');

// Routes API pour les données en temps réel
$router->get('/api/realtime/stats', 'ApiController@realtimeStats');
$router->get('/api/realtime/notifications', 'ApiController@realtimeNotifications');
$router->get('/api/realtime/activity', 'ApiController@realtimeActivity');

// Routes pour les paramètres utilisateur
$router->get('/settings', 'SettingsController@index');
$router->post('/settings/profile', 'SettingsController@updateProfile');
$router->post('/settings/password', 'SettingsController@changePassword');
$router->post('/settings/preferences', 'SettingsController@updatePreferences');

// Routes pour l'aide et la documentation
$router->get('/help', 'HelpController@index');
$router->get('/help/{section}', 'HelpController@section');
$router->get('/about', 'HelpController@about');

// Middleware pour vérifier l'authentification sur les routes protégées
function authMiddleware() {
    $publicRoutes = ['/', '/login', '/forgot-password', '/reset-password'];
    $currentRoute = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    
    if (!in_array($currentRoute, $publicRoutes) && !isset($_SESSION['user_id'])) {
        header('Location: /login');
        exit;
    }
    
    return true;
}

// Middleware pour vérifier l'expiration de session
function sessionMiddleware() {
    if (isset($_SESSION['user_id'])) {
        $sessionLifetime = (int)($_ENV['SESSION_LIFETIME'] ?? 7200); // 2 heures par défaut
        $lastActivity = $_SESSION['last_activity'] ?? 0;
        
        if (time() - $lastActivity > $sessionLifetime) {
            session_destroy();
            header('Location: /login?expired=1');
            exit;
        }
        
        $_SESSION['last_activity'] = time();
    }
    
    return true;
}

// Appliquer les middlewares
authMiddleware();
sessionMiddleware();

try {
    // Résoudre la route
    $router->resolve();
} catch (Exception $e) {
    // Gestion des erreurs
    error_log("Erreur de routage: " . $e->getMessage());
    
    if ($_ENV['APP_ENV'] === 'development') {
        echo "<h1>Erreur</h1>";
        echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
    } else {
        http_response_code(500);
        echo "<h1>Erreur interne du serveur</h1>";
        echo "<p>Une erreur s'est produite. Veuillez réessayer plus tard.</p>";
    }
}


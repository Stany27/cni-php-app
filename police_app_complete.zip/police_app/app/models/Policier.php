<?php

namespace App\Models;

use Core\Model;

class Policier extends Model
{
    protected $table = 'policiers';
    protected $fillable = [
        'user_id', 'nom', 'prenom', 'matricule', 'grade', 'poste', 
        'localisation', 'date_naissance', 'lieu_naissance', 'sexe', 
        'telephone', 'adresse', 'photo'
    ];

    public function getByUserId($userId)
    {
        return $this->findBy('user_id', $userId);
    }

    public function getByMatricule($matricule)
    {
        return $this->findBy('matricule', $matricule);
    }

    public function searchPoliciers($query, $limit = 10, $offset = 0)
    {
        return $this->search($query, ['nom', 'prenom', 'matricule', 'grade', 'poste', 'localisation'], $limit, $offset);
    }

    public function getByGrade($grade)
    {
        return $this->where(['grade' => $grade]);
    }

    public function getByLocalisation($localisation)
    {
        return $this->where(['localisation' => $localisation]);
    }

    public function getByPoste($poste)
    {
        return $this->where(['poste' => $poste]);
    }

    public function getPolicierWithUser($policierId)
    {
        $sql = "SELECT p.*, u.username, u.email, u.role, u.created_at as user_created_at 
                FROM policiers p 
                INNER JOIN utilisateurs u ON p.user_id = u.id 
                WHERE p.id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$policierId]);
        
        return $stmt->fetch();
    }

    public function getAllWithUsers($limit = null, $offset = 0)
    {
        $sql = "SELECT p.*, u.username, u.email, u.role 
                FROM policiers p 
                INNER JOIN utilisateurs u ON p.user_id = u.id 
                ORDER BY p.nom, p.prenom";
        
        if ($limit) {
            $sql .= " LIMIT {$limit} OFFSET {$offset}";
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getStatsByGrade()
    {
        $sql = "SELECT grade, COUNT(*) as count FROM {$this->table} GROUP BY grade ORDER BY count DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getStatsByLocalisation()
    {
        $sql = "SELECT localisation, COUNT(*) as count FROM {$this->table} GROUP BY localisation ORDER BY count DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getStatsByPoste()
    {
        $sql = "SELECT poste, COUNT(*) as count FROM {$this->table} GROUP BY poste ORDER BY count DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getStatsBySexe()
    {
        $sql = "SELECT sexe, COUNT(*) as count FROM {$this->table} GROUP BY sexe";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getAgeStats()
    {
        $sql = "SELECT 
                    CASE 
                        WHEN TIMESTAMPDIFF(YEAR, date_naissance, CURDATE()) < 25 THEN 'Moins de 25 ans'
                        WHEN TIMESTAMPDIFF(YEAR, date_naissance, CURDATE()) BETWEEN 25 AND 35 THEN '25-35 ans'
                        WHEN TIMESTAMPDIFF(YEAR, date_naissance, CURDATE()) BETWEEN 36 AND 45 THEN '36-45 ans'
                        WHEN TIMESTAMPDIFF(YEAR, date_naissance, CURDATE()) BETWEEN 46 AND 55 THEN '46-55 ans'
                        ELSE 'Plus de 55 ans'
                    END as tranche_age,
                    COUNT(*) as count
                FROM {$this->table} 
                GROUP BY tranche_age 
                ORDER BY count DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function isMatriculeExists($matricule, $excludeId = null)
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE matricule = ?";
        $params = [$matricule];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        
        return $result['count'] > 0;
    }

    public function getRecentlyAdded($limit = 10)
    {
        $sql = "SELECT p.*, u.username 
                FROM policiers p 
                INNER JOIN utilisateurs u ON p.user_id = u.id 
                ORDER BY p.created_at DESC 
                LIMIT {$limit}";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function advancedSearch($filters, $limit = 10, $offset = 0)
    {
        $whereClause = [];
        $params = [];
        
        if (!empty($filters['nom'])) {
            $whereClause[] = "p.nom LIKE ?";
            $params[] = "%{$filters['nom']}%";
        }
        
        if (!empty($filters['prenom'])) {
            $whereClause[] = "p.prenom LIKE ?";
            $params[] = "%{$filters['prenom']}%";
        }
        
        if (!empty($filters['matricule'])) {
            $whereClause[] = "p.matricule LIKE ?";
            $params[] = "%{$filters['matricule']}%";
        }
        
        if (!empty($filters['grade'])) {
            $whereClause[] = "p.grade = ?";
            $params[] = $filters['grade'];
        }
        
        if (!empty($filters['poste'])) {
            $whereClause[] = "p.poste = ?";
            $params[] = $filters['poste'];
        }
        
        if (!empty($filters['localisation'])) {
            $whereClause[] = "p.localisation = ?";
            $params[] = $filters['localisation'];
        }
        
        if (!empty($filters['sexe'])) {
            $whereClause[] = "p.sexe = ?";
            $params[] = $filters['sexe'];
        }
        
        $sql = "SELECT p.*, u.username, u.email 
                FROM policiers p 
                INNER JOIN utilisateurs u ON p.user_id = u.id";
        
        if (!empty($whereClause)) {
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }
        
        $sql .= " ORDER BY p.nom, p.prenom LIMIT {$limit} OFFSET {$offset}";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll();
    }
}


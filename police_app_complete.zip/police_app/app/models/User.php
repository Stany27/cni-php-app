<?php

namespace App\Models;

use Core\Model;

class User extends Model
{
    protected $table = 'utilisateurs';
    protected $fillable = ['username', 'password', 'email', 'role'];
    protected $hidden = ['password'];

    public function authenticate($username, $password)
    {
        $user = $this->findBy('username', $username);
        
        if ($user && password_verify($password, $user['password'])) {
            return $this->hideFields($user);
        }
        
        return false;
    }

    public function createUser($data)
    {
        // Hasher le mot de passe
        if (isset($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        }
        
        return $this->create($data);
    }

    public function updatePassword($userId, $newPassword)
    {
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
        return $this->update($userId, ['password' => $hashedPassword]);
    }

    public function getUsersByRole($role)
    {
        return $this->where(['role' => $role]);
    }

    public function searchUsers($query, $limit = 10, $offset = 0)
    {
        return $this->search($query, ['username', 'email'], $limit, $offset);
    }

    public function getUserWithPolicier($userId)
    {
        $sql = "SELECT u.*, p.nom, p.prenom, p.matricule, p.grade, p.poste, p.localisation 
                FROM utilisateurs u 
                LEFT JOIN policiers p ON u.id = p.user_id 
                WHERE u.id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$userId]);
        $result = $stmt->fetch();
        
        return $result ? $this->hideFields($result) : null;
    }

    public function isEmailExists($email, $excludeId = null)
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE email = ?";
        $params = [$email];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        
        return $result['count'] > 0;
    }

    public function isUsernameExists($username, $excludeId = null)
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE username = ?";
        $params = [$username];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        
        return $result['count'] > 0;
    }

    public function getActiveUsers()
    {
        // Utilisateurs actifs dans les 30 derniers jours
        $sql = "SELECT u.*, MAX(l.created_at) as last_activity 
                FROM utilisateurs u 
                LEFT JOIN logs l ON u.id = l.user_id 
                WHERE l.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) 
                GROUP BY u.id 
                ORDER BY last_activity DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
        
        return array_map([$this, 'hideFields'], $results);
    }

    public function getUserStats()
    {
        $sql = "SELECT 
                    role,
                    COUNT(*) as count
                FROM {$this->table} 
                GROUP BY role";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}


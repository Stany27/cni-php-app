<?php

namespace App\Models;

use Core\Model;

class Demande extends Model
{
    protected $table = 'demandes';
    protected $fillable = ['policier_id', 'type_demande', 'description', 'statut'];

    public function getByPolicier($policierId)
    {
        return $this->where(['policier_id' => $policierId]);
    }

    public function getByStatut($statut)
    {
        return $this->where(['statut' => $statut]);
    }

    public function getByType($type)
    {
        return $this->where(['type_demande' => $type]);
    }

    public function getDemandesWithPolicier($limit = null, $offset = 0)
    {
        $sql = "SELECT d.*, p.nom, p.prenom, p.matricule, p.grade, p.poste, p.localisation 
                FROM demandes d 
                INNER JOIN policiers p ON d.policier_id = p.id 
                ORDER BY d.created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT {$limit} OFFSET {$offset}";
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getDemandeWithPolicier($demandeId)
    {
        $sql = "SELECT d.*, p.nom, p.prenom, p.matricule, p.grade, p.poste, p.localisation, u.email 
                FROM demandes d 
                INNER JOIN policiers p ON d.policier_id = p.id 
                INNER JOIN utilisateurs u ON p.user_id = u.id 
                WHERE d.id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$demandeId]);
        
        return $stmt->fetch();
    }

    public function updateStatut($demandeId, $statut)
    {
        return $this->update($demandeId, ['statut' => $statut]);
    }

    public function getStatsByType()
    {
        $sql = "SELECT type_demande, COUNT(*) as count FROM {$this->table} GROUP BY type_demande ORDER BY count DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getStatsByStatut()
    {
        $sql = "SELECT statut, COUNT(*) as count FROM {$this->table} GROUP BY statut";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getDemandesEnAttente($limit = null)
    {
        $sql = "SELECT d.*, p.nom, p.prenom, p.matricule, p.grade 
                FROM demandes d 
                INNER JOIN policiers p ON d.policier_id = p.id 
                WHERE d.statut = 'en_attente' 
                ORDER BY d.created_at ASC";
        
        if ($limit) {
            $sql .= " LIMIT {$limit}";
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getRecentDemandes($limit = 10)
    {
        $sql = "SELECT d.*, p.nom, p.prenom, p.matricule 
                FROM demandes d 
                INNER JOIN policiers p ON d.policier_id = p.id 
                ORDER BY d.created_at DESC 
                LIMIT {$limit}";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function searchDemandes($query, $limit = 10, $offset = 0)
    {
        $sql = "SELECT d.*, p.nom, p.prenom, p.matricule, p.grade 
                FROM demandes d 
                INNER JOIN policiers p ON d.policier_id = p.id 
                WHERE p.nom LIKE ? OR p.prenom LIKE ? OR p.matricule LIKE ? OR d.type_demande LIKE ? OR d.description LIKE ?
                ORDER BY d.created_at DESC 
                LIMIT {$limit} OFFSET {$offset}";
        
        $searchTerm = "%{$query}%";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        
        return $stmt->fetchAll();
    }

    public function advancedSearch($filters, $limit = 10, $offset = 0)
    {
        $whereClause = [];
        $params = [];
        
        if (!empty($filters['type_demande'])) {
            $whereClause[] = "d.type_demande = ?";
            $params[] = $filters['type_demande'];
        }
        
        if (!empty($filters['statut'])) {
            $whereClause[] = "d.statut = ?";
            $params[] = $filters['statut'];
        }
        
        if (!empty($filters['policier_nom'])) {
            $whereClause[] = "(p.nom LIKE ? OR p.prenom LIKE ?)";
            $params[] = "%{$filters['policier_nom']}%";
            $params[] = "%{$filters['policier_nom']}%";
        }
        
        if (!empty($filters['matricule'])) {
            $whereClause[] = "p.matricule LIKE ?";
            $params[] = "%{$filters['matricule']}%";
        }
        
        if (!empty($filters['date_debut'])) {
            $whereClause[] = "DATE(d.created_at) >= ?";
            $params[] = $filters['date_debut'];
        }
        
        if (!empty($filters['date_fin'])) {
            $whereClause[] = "DATE(d.created_at) <= ?";
            $params[] = $filters['date_fin'];
        }
        
        $sql = "SELECT d.*, p.nom, p.prenom, p.matricule, p.grade, p.poste, p.localisation 
                FROM demandes d 
                INNER JOIN policiers p ON d.policier_id = p.id";
        
        if (!empty($whereClause)) {
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }
        
        $sql .= " ORDER BY d.created_at DESC LIMIT {$limit} OFFSET {$offset}";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll();
    }

    public function getMonthlyStats($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "SELECT 
                    MONTH(created_at) as mois,
                    COUNT(*) as total,
                    SUM(CASE WHEN statut = 'approuvee' THEN 1 ELSE 0 END) as approuvees,
                    SUM(CASE WHEN statut = 'rejetee' THEN 1 ELSE 0 END) as rejetees,
                    SUM(CASE WHEN statut = 'en_attente' THEN 1 ELSE 0 END) as en_attente
                FROM {$this->table} 
                WHERE YEAR(created_at) = ? 
                GROUP BY MONTH(created_at) 
                ORDER BY mois";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$year]);
        
        return $stmt->fetchAll();
    }

    public function getDemandesByLocalisation()
    {
        $sql = "SELECT p.localisation, COUNT(*) as count 
                FROM demandes d 
                INNER JOIN policiers p ON d.policier_id = p.id 
                GROUP BY p.localisation 
                ORDER BY count DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}


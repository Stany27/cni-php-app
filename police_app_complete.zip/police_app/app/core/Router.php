<?php

namespace Core;

class Router
{
    private $routes = [];
    private $middlewares = [];

    public function get($path, $callback, $middleware = null)
    {
        $this->addRoute('GET', $path, $callback, $middleware);
    }

    public function post($path, $callback, $middleware = null)
    {
        $this->addRoute('POST', $path, $callback, $middleware);
    }

    public function put($path, $callback, $middleware = null)
    {
        $this->addRoute('PUT', $path, $callback, $middleware);
    }

    public function delete($path, $callback, $middleware = null)
    {
        $this->addRoute('DELETE', $path, $callback, $middleware);
    }

    private function addRoute($method, $path, $callback, $middleware = null)
    {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'callback' => $callback,
            'middleware' => $middleware
        ];
    }

    public function resolve()
    {
        $requestMethod = $_SERVER['REQUEST_METHOD'];
        $requestPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        // Supprimer le slash final sauf pour la racine
        if ($requestPath !== '/' && substr($requestPath, -1) === '/') {
            $requestPath = rtrim($requestPath, '/');
        }

        foreach ($this->routes as $route) {
            if ($route['method'] === $requestMethod) {
                $pattern = $this->convertToRegex($route['path']);
                
                if (preg_match($pattern, $requestPath, $matches)) {
                    // Supprimer le premier élément (match complet)
                    array_shift($matches);
                    
                    // Exécuter le middleware si défini
                    if ($route['middleware']) {
                        $middlewareResult = $this->executeMiddleware($route['middleware']);
                        if ($middlewareResult !== true) {
                            return $middlewareResult;
                        }
                    }
                    
                    return $this->executeCallback($route['callback'], $matches);
                }
            }
        }

        // Route non trouvée
        http_response_code(404);
        return $this->render404();
    }

    private function convertToRegex($path)
    {
        // Convertir les paramètres {id} en regex
        $pattern = preg_replace('/\{([^}]+)\}/', '([^/]+)', $path);
        return '#^' . $pattern . '$#';
    }

    private function executeCallback($callback, $params = [])
    {
        if (is_string($callback)) {
            // Format: "ControllerName@methodName"
            if (strpos($callback, '@') !== false) {
                list($controller, $method) = explode('@', $callback);
                $controllerClass = "App\\Controllers\\" . $controller;
                
                if (class_exists($controllerClass)) {
                    $controllerInstance = new $controllerClass();
                    if (method_exists($controllerInstance, $method)) {
                        return call_user_func_array([$controllerInstance, $method], $params);
                    }
                }
            }
        } elseif (is_callable($callback)) {
            return call_user_func_array($callback, $params);
        }

        throw new \Exception("Route callback non valide");
    }

    private function executeMiddleware($middleware)
    {
        if (is_string($middleware)) {
            $middlewareClass = "App\\Middlewares\\" . $middleware;
            if (class_exists($middlewareClass)) {
                $middlewareInstance = new $middlewareClass();
                return $middlewareInstance->handle();
            }
        } elseif (is_callable($middleware)) {
            return call_user_func($middleware);
        }

        return true;
    }

    private function render404()
    {
        return "Page non trouvée";
    }
}


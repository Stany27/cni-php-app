<?php

namespace Core;

use Twig\Environment;
use Twig\Loader\FilesystemLoader;

abstract class Controller
{
    protected $twig;
    protected $db;

    public function __construct()
    {
        $this->initializeTwig();
        $this->initializeDatabase();
    }

    private function initializeTwig()
    {
        $loader = new FilesystemLoader(__DIR__ . '/../views');
        $this->twig = new Environment($loader, [
            'cache' => $_ENV['APP_ENV'] === 'production' ? __DIR__ . '/../../cache' : false,
            'debug' => $_ENV['APP_DEBUG'] === 'true',
        ]);

        // Ajouter des variables globales
        $this->twig->addGlobal('app_name', $_ENV['APP_NAME'] ?? 'Police App');
        $this->twig->addGlobal('app_url', $_ENV['APP_URL'] ?? 'http://localhost');
        $this->twig->addGlobal('csrf_token', $this->generateCSRFToken());
    }

    private function initializeDatabase()
    {
        $database = new \App\Config\Database();
        $this->db = $database->getConnection();
    }

    protected function render($template, $data = [])
    {
        try {
            echo $this->twig->render($template, $data);
        } catch (\Exception $e) {
            error_log("Template error: " . $e->getMessage());
            $this->renderError("Erreur de template");
        }
    }

    protected function json($data, $status = 200)
    {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    }

    protected function redirect($url, $status = 302)
    {
        http_response_code($status);
        header("Location: $url");
        exit;
    }

    protected function renderError($message, $status = 500)
    {
        http_response_code($status);
        echo "<h1>Erreur $status</h1><p>$message</p>";
    }

    protected function validateCSRF($token)
    {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    protected function generateCSRFToken()
    {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    protected function sanitizeInput($input)
    {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        }
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }

    protected function validateInput($data, $rules)
    {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $data[$field] ?? null;
            
            if (strpos($rule, 'required') !== false && empty($value)) {
                $errors[$field] = "Le champ $field est requis";
                continue;
            }
            
            if (!empty($value)) {
                if (strpos($rule, 'email') !== false && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[$field] = "Le champ $field doit être un email valide";
                }
                
                if (preg_match('/min:(\d+)/', $rule, $matches)) {
                    $min = (int)$matches[1];
                    if (strlen($value) < $min) {
                        $errors[$field] = "Le champ $field doit contenir au moins $min caractères";
                    }
                }
                
                if (preg_match('/max:(\d+)/', $rule, $matches)) {
                    $max = (int)$matches[1];
                    if (strlen($value) > $max) {
                        $errors[$field] = "Le champ $field ne peut pas dépasser $max caractères";
                    }
                }
            }
        }
        
        return $errors;
    }

    protected function logAction($action, $details = null)
    {
        try {
            $stmt = $this->db->prepare("INSERT INTO logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                $_SESSION['user_id'] ?? null,
                $action,
                $details ? json_encode($details) : null,
                $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);
        } catch (\Exception $e) {
            error_log("Log error: " . $e->getMessage());
        }
    }

    protected function requireAuth()
    {
        if (!isset($_SESSION['user_id'])) {
            $this->redirect('/login');
        }
    }

    protected function requireRole($roles)
    {
        $this->requireAuth();
        
        if (!in_array($_SESSION['user_role'] ?? '', (array)$roles)) {
            http_response_code(403);
            $this->renderError("Accès non autorisé", 403);
            exit;
        }
    }
}


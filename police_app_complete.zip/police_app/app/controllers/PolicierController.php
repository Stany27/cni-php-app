<?php

namespace App\Controllers;

use Core\Controller;
use App\Models\User;
use App\Models\Policier;
use App\Models\Demande;

class PolicierController extends Controller
{
    private $userModel;
    private $policierModel;
    private $demandeModel;

    public function __construct()
    {
        parent::__construct();
        $this->requireAuth();
        $this->userModel = new User();
        $this->policierModel = new Policier();
        $this->demandeModel = new Demande();
    }

    public function index()
    {
        $this->requireRole(['DGSN', 'DRH', 'Délégué Régional', 'Superviseur']);

        $page = (int)($_GET['page'] ?? 1);
        $perPage = 20;
        $search = $_GET['search'] ?? '';

        if ($search) {
            $policiers = $this->policierModel->searchPoliciers($search, $perPage, ($page - 1) * $perPage);
            $total = count($policiers); // Approximation pour la recherche
        } else {
            $result = $this->policierModel->paginate($page, $perPage);
            $policiers = $result['data'];
            $total = $result['total'];
        }

        $data = [
            'policiers' => $policiers,
            'current_page' => $page,
            'total_pages' => ceil($total / $perPage),
            'search' => $search,
            'total' => $total
        ];

        $this->render('policier/index.twig', $data);
    }

    public function show($id)
    {
        $this->requireRole(['DGSN', 'DRH', 'Délégué Régional', 'Superviseur']);

        $policier = $this->policierModel->getPolicierWithUser($id);

        if (!$policier) {
            $this->renderError('Policier non trouvé', 404);
            return;
        }

        // Récupérer les demandes du policier
        $demandes = $this->demandeModel->getByPolicier($id);

        $data = [
            'policier' => $policier,
            'demandes' => $demandes
        ];

        $this->render('policier/show.twig', $data);
    }

    public function create()
    {
        $this->requireRole(['DGSN', 'DRH', 'Délégué Régional']);

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->render('policier/create.twig');
            return;
        }

        // Validation CSRF
        if (!$this->validateCSRF($_POST['csrf_token'] ?? '')) {
            $this->json(['success' => false, 'message' => 'Token CSRF invalide'], 400);
            return;
        }

        $userData = [
            'username' => $this->sanitizeInput($_POST['username'] ?? ''),
            'email' => $this->sanitizeInput($_POST['email'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'role' => 'Policier'
        ];

        $policierData = [
            'nom' => $this->sanitizeInput($_POST['nom'] ?? ''),
            'prenom' => $this->sanitizeInput($_POST['prenom'] ?? ''),
            'matricule' => $this->sanitizeInput($_POST['matricule'] ?? ''),
            'grade' => $this->sanitizeInput($_POST['grade'] ?? ''),
            'poste' => $this->sanitizeInput($_POST['poste'] ?? ''),
            'localisation' => $this->sanitizeInput($_POST['localisation'] ?? ''),
            'date_naissance' => $_POST['date_naissance'] ?? '',
            'lieu_naissance' => $this->sanitizeInput($_POST['lieu_naissance'] ?? ''),
            'sexe' => $_POST['sexe'] ?? '',
            'telephone' => $this->sanitizeInput($_POST['telephone'] ?? ''),
            'adresse' => $this->sanitizeInput($_POST['adresse'] ?? '')
        ];

        // Validation
        $errors = $this->validatePolicierData($userData, $policierData);

        if (!empty($errors)) {
            $this->json(['success' => false, 'errors' => $errors], 400);
            return;
        }

        try {
            $this->userModel->beginTransaction();

            // Créer l'utilisateur
            $user = $this->userModel->createUser($userData);
            if (!$user) {
                throw new \Exception('Erreur lors de la création de l\'utilisateur');
            }

            // Créer le profil policier
            $policierData['user_id'] = $user['id'];
            $policier = $this->policierModel->create($policierData);
            if (!$policier) {
                throw new \Exception('Erreur lors de la création du profil policier');
            }

            // Gérer l'upload de photo si présent
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $photoPath = $this->handlePhotoUpload($_FILES['photo'], $policier['id']);
                if ($photoPath) {
                    $this->policierModel->update($policier['id'], ['photo' => $photoPath]);
                }
            }

            $this->userModel->commit();
            $this->logAction('policier_created', ['policier_id' => $policier['id'], 'matricule' => $policierData['matricule']]);

            $this->json(['success' => true, 'message' => 'Policier créé avec succès', 'redirect' => '/policier/' . $policier['id']]);

        } catch (\Exception $e) {
            $this->userModel->rollback();
            error_log("Erreur création policier: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Erreur lors de la création du policier'], 500);
        }
    }

    public function edit($id)
    {
        $this->requireRole(['DGSN', 'DRH', 'Délégué Régional']);

        $policier = $this->policierModel->getPolicierWithUser($id);

        if (!$policier) {
            $this->renderError('Policier non trouvé', 404);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->render('policier/edit.twig', ['policier' => $policier]);
            return;
        }

        // Validation CSRF
        if (!$this->validateCSRF($_POST['csrf_token'] ?? '')) {
            $this->json(['success' => false, 'message' => 'Token CSRF invalide'], 400);
            return;
        }

        $userData = [
            'username' => $this->sanitizeInput($_POST['username'] ?? ''),
            'email' => $this->sanitizeInput($_POST['email'] ?? '')
        ];

        $policierData = [
            'nom' => $this->sanitizeInput($_POST['nom'] ?? ''),
            'prenom' => $this->sanitizeInput($_POST['prenom'] ?? ''),
            'matricule' => $this->sanitizeInput($_POST['matricule'] ?? ''),
            'grade' => $this->sanitizeInput($_POST['grade'] ?? ''),
            'poste' => $this->sanitizeInput($_POST['poste'] ?? ''),
            'localisation' => $this->sanitizeInput($_POST['localisation'] ?? ''),
            'date_naissance' => $_POST['date_naissance'] ?? '',
            'lieu_naissance' => $this->sanitizeInput($_POST['lieu_naissance'] ?? ''),
            'sexe' => $_POST['sexe'] ?? '',
            'telephone' => $this->sanitizeInput($_POST['telephone'] ?? ''),
            'adresse' => $this->sanitizeInput($_POST['adresse'] ?? '')
        ];

        // Validation
        $errors = $this->validatePolicierData($userData, $policierData, $id);

        if (!empty($errors)) {
            $this->json(['success' => false, 'errors' => $errors], 400);
            return;
        }

        try {
            $this->userModel->beginTransaction();

            // Mettre à jour l'utilisateur
            $this->userModel->update($policier['user_id'], $userData);

            // Mettre à jour le profil policier
            $this->policierModel->update($id, $policierData);

            // Gérer l'upload de photo si présent
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $photoPath = $this->handlePhotoUpload($_FILES['photo'], $id);
                if ($photoPath) {
                    $this->policierModel->update($id, ['photo' => $photoPath]);
                }
            }

            $this->userModel->commit();
            $this->logAction('policier_updated', ['policier_id' => $id, 'matricule' => $policierData['matricule']]);

            $this->json(['success' => true, 'message' => 'Policier mis à jour avec succès']);

        } catch (\Exception $e) {
            $this->userModel->rollback();
            error_log("Erreur mise à jour policier: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Erreur lors de la mise à jour'], 500);
        }
    }

    public function delete($id)
    {
        $this->requireRole(['DGSN', 'DRH']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['success' => false, 'message' => 'Méthode non autorisée'], 405);
            return;
        }

        // Validation CSRF
        if (!$this->validateCSRF($_POST['csrf_token'] ?? '')) {
            $this->json(['success' => false, 'message' => 'Token CSRF invalide'], 400);
            return;
        }

        $policier = $this->policierModel->find($id);

        if (!$policier) {
            $this->json(['success' => false, 'message' => 'Policier non trouvé'], 404);
            return;
        }

        try {
            $this->userModel->beginTransaction();

            // Supprimer le policier (cascade supprimera l'utilisateur)
            $this->policierModel->delete($id);

            $this->userModel->commit();
            $this->logAction('policier_deleted', ['policier_id' => $id, 'matricule' => $policier['matricule']]);

            $this->json(['success' => true, 'message' => 'Policier supprimé avec succès']);

        } catch (\Exception $e) {
            $this->userModel->rollback();
            error_log("Erreur suppression policier: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Erreur lors de la suppression'], 500);
        }
    }

    public function search()
    {
        $this->requireRole(['DGSN', 'DRH', 'Délégué Régional', 'Superviseur']);

        $query = $_GET['q'] ?? '';
        $filters = [
            'grade' => $_GET['grade'] ?? '',
            'poste' => $_GET['poste'] ?? '',
            'localisation' => $_GET['localisation'] ?? '',
            'sexe' => $_GET['sexe'] ?? ''
        ];

        $page = (int)($_GET['page'] ?? 1);
        $perPage = 20;

        if ($query) {
            $results = $this->policierModel->searchPoliciers($query, $perPage, ($page - 1) * $perPage);
        } else {
            $results = $this->policierModel->advancedSearch($filters, $perPage, ($page - 1) * $perPage);
        }

        $this->json([
            'success' => true,
            'data' => $results,
            'page' => $page,
            'per_page' => $perPage
        ]);
    }

    public function profile()
    {
        // Profil du policier connecté
        $this->requireRole(['Policier']);

        $policier = $this->policierModel->getByUserId($_SESSION['user_id']);

        if (!$policier) {
            $this->renderError('Profil non trouvé', 404);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->render('policier/profile.twig', ['policier' => $policier]);
            return;
        }

        // Mise à jour du profil
        if (!$this->validateCSRF($_POST['csrf_token'] ?? '')) {
            $this->json(['success' => false, 'message' => 'Token CSRF invalide'], 400);
            return;
        }

        $allowedFields = ['telephone', 'adresse'];
        $updateData = [];

        foreach ($allowedFields as $field) {
            if (isset($_POST[$field])) {
                $updateData[$field] = $this->sanitizeInput($_POST[$field]);
            }
        }

        if (!empty($updateData)) {
            $this->policierModel->update($policier['id'], $updateData);
            $this->logAction('profile_updated', ['policier_id' => $policier['id']]);
        }

        $this->json(['success' => true, 'message' => 'Profil mis à jour avec succès']);
    }

    public function exportList()
    {
        $this->requireRole(['DGSN', 'DRH', 'Délégué Régional']);

        $format = $_GET['format'] ?? 'pdf';
        $filters = [
            'grade' => $_GET['grade'] ?? '',
            'poste' => $_GET['poste'] ?? '',
            'localisation' => $_GET['localisation'] ?? ''
        ];

        $policiers = $this->policierModel->advancedSearch($filters, 1000, 0);

        switch ($format) {
            case 'pdf':
                $this->exportToPDF($policiers);
                break;
            case 'excel':
                $this->exportToExcel($policiers);
                break;
            case 'csv':
                $this->exportToCSV($policiers);
                break;
            default:
                $this->json(['success' => false, 'message' => 'Format non supporté'], 400);
        }
    }

    private function validatePolicierData($userData, $policierData, $excludeId = null)
    {
        $errors = [];

        // Validation utilisateur
        $userErrors = $this->validateInput($userData, [
            'username' => 'required|min:3|max:50',
            'email' => 'required|email|max:100'
        ]);
        $errors = array_merge($errors, $userErrors);

        // Validation policier
        $policierErrors = $this->validateInput($policierData, [
            'nom' => 'required|min:2|max:100',
            'prenom' => 'required|min:2|max:100',
            'matricule' => 'required|min:3|max:20',
            'grade' => 'required|max:50',
            'poste' => 'required|max:100',
            'localisation' => 'required|max:100',
            'date_naissance' => 'required',
            'lieu_naissance' => 'required|max:100',
            'sexe' => 'required',
            'telephone' => 'required|max:20',
            'adresse' => 'required'
        ]);
        $errors = array_merge($errors, $policierErrors);

        // Vérifications d'unicité
        if ($this->userModel->isUsernameExists($userData['username'], $excludeId)) {
            $errors['username'] = 'Ce nom d\'utilisateur existe déjà';
        }

        if ($this->userModel->isEmailExists($userData['email'], $excludeId)) {
            $errors['email'] = 'Cette adresse email existe déjà';
        }

        if ($this->policierModel->isMatriculeExists($policierData['matricule'], $excludeId)) {
            $errors['matricule'] = 'Ce matricule existe déjà';
        }

        // Validation de la date de naissance
        if (!empty($policierData['date_naissance'])) {
            $birthDate = \DateTime::createFromFormat('Y-m-d', $policierData['date_naissance']);
            if (!$birthDate || $birthDate->format('Y-m-d') !== $policierData['date_naissance']) {
                $errors['date_naissance'] = 'Date de naissance invalide';
            } else {
                $age = $birthDate->diff(new \DateTime())->y;
                if ($age < 18 || $age > 65) {
                    $errors['date_naissance'] = 'L\'âge doit être entre 18 et 65 ans';
                }
            }
        }

        // Validation du sexe
        if (!in_array($policierData['sexe'], ['Homme', 'Femme'])) {
            $errors['sexe'] = 'Sexe invalide';
        }

        return $errors;
    }

    private function handlePhotoUpload($file, $policierId)
    {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 5 * 1024 * 1024; // 5MB

        if (!in_array($file['type'], $allowedTypes)) {
            return false;
        }

        if ($file['size'] > $maxSize) {
            return false;
        }

        $uploadDir = __DIR__ . '/../../public/uploads/photos/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'policier_' . $policierId . '_' . time() . '.' . $extension;
        $uploadPath = $uploadDir . $filename;

        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            return 'uploads/photos/' . $filename;
        }

        return false;
    }

    private function exportToPDF($policiers)
    {
        require_once __DIR__ . '/../../vendor/autoload.php';
        
        $dompdf = new \Dompdf\Dompdf();
        
        $html = $this->twig->render('policier/export_pdf.twig', [
            'policiers' => $policiers,
            'generated_at' => date('d/m/Y H:i:s')
        ]);
        
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();
        
        $filename = "liste_policiers_" . date('Y-m-d') . ".pdf";
        $dompdf->stream($filename, ['Attachment' => true]);
    }

    private function exportToExcel($policiers)
    {
        require_once __DIR__ . '/../../vendor/autoload.php';
        
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        
        // En-têtes
        $headers = ['Matricule', 'Nom', 'Prénom', 'Grade', 'Poste', 'Localisation', 'Téléphone', 'Email'];
        $sheet->fromArray($headers, null, 'A1');
        
        // Données
        $row = 2;
        foreach ($policiers as $policier) {
            $sheet->fromArray([
                $policier['matricule'],
                $policier['nom'],
                $policier['prenom'],
                $policier['grade'],
                $policier['poste'],
                $policier['localisation'],
                $policier['telephone'],
                $policier['email']
            ], null, 'A' . $row);
            $row++;
        }
        
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        
        $filename = "liste_policiers_" . date('Y-m-d') . ".xlsx";
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        
        $writer->save('php://output');
    }

    private function exportToCSV($policiers)
    {
        $filename = "liste_policiers_" . date('Y-m-d') . ".csv";
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // En-têtes
        fputcsv($output, ['Matricule', 'Nom', 'Prénom', 'Grade', 'Poste', 'Localisation', 'Téléphone', 'Email']);
        
        // Données
        foreach ($policiers as $policier) {
            fputcsv($output, [
                $policier['matricule'],
                $policier['nom'],
                $policier['prenom'],
                $policier['grade'],
                $policier['poste'],
                $policier['localisation'],
                $policier['telephone'],
                $policier['email']
            ]);
        }
        
        fclose($output);
    }
}


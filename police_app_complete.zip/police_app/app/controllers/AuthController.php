<?php

namespace App\Controllers;

use Core\Controller;
use App\Models\User;
use App\Models\Policier;

class AuthController extends Controller
{
    private $userModel;
    private $policierModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
        $this->policierModel = new Policier();
    }

    public function showLogin()
    {
        // Si déjà connecté, rediriger vers le tableau de bord
        if (isset($_SESSION['user_id'])) {
            $this->redirect('/dashboard');
        }

        $this->render('auth/login.twig');
    }

    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/login');
        }

        // Validation CSRF
        if (!$this->validateCSRF($_POST['csrf_token'] ?? '')) {
            $this->json(['success' => false, 'message' => 'Token CSRF invalide'], 400);
            return;
        }

        $username = $this->sanitizeInput($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);

        // Validation des champs
        $errors = $this->validateInput([
            'username' => $username,
            'password' => $password
        ], [
            'username' => 'required|min:3',
            'password' => 'required|min:6'
        ]);

        if (!empty($errors)) {
            $this->json(['success' => false, 'errors' => $errors], 400);
            return;
        }

        // Vérification des tentatives de connexion
        if ($this->isAccountLocked($username)) {
            $this->json(['success' => false, 'message' => 'Compte temporairement verrouillé. Réessayez plus tard.'], 429);
            return;
        }

        // Authentification
        $user = $this->userModel->authenticate($username, $password);

        if ($user) {
            // Connexion réussie
            $this->createSession($user, $remember);
            $this->resetLoginAttempts($username);
            $this->logAction('login_success', ['username' => $username]);

            // Redirection selon le rôle
            $redirectUrl = $this->getRedirectUrl($user['role']);
            
            $this->json([
                'success' => true, 
                'message' => 'Connexion réussie',
                'redirect' => $redirectUrl
            ]);
        } else {
            // Connexion échouée
            $this->incrementLoginAttempts($username);
            $this->logAction('login_failed', ['username' => $username]);
            
            $this->json(['success' => false, 'message' => 'Nom d\'utilisateur ou mot de passe incorrect'], 401);
        }
    }

    public function logout()
    {
        $this->logAction('logout', ['user_id' => $_SESSION['user_id'] ?? null]);
        
        // Détruire la session
        session_destroy();
        
        // Supprimer le cookie de connexion automatique
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/');
        }

        $this->redirect('/login');
    }

    public function showRegister()
    {
        // Seuls les administrateurs peuvent accéder à l'inscription
        $this->requireRole(['DGSN', 'DRH']);
        
        $this->render('auth/register.twig');
    }

    public function register()
    {
        $this->requireRole(['DGSN', 'DRH']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/register');
        }

        // Validation CSRF
        if (!$this->validateCSRF($_POST['csrf_token'] ?? '')) {
            $this->json(['success' => false, 'message' => 'Token CSRF invalide'], 400);
            return;
        }

        $data = [
            'username' => $this->sanitizeInput($_POST['username'] ?? ''),
            'email' => $this->sanitizeInput($_POST['email'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'password_confirm' => $_POST['password_confirm'] ?? '',
            'role' => $this->sanitizeInput($_POST['role'] ?? '')
        ];

        // Validation des champs
        $errors = $this->validateInput($data, [
            'username' => 'required|min:3|max:50',
            'email' => 'required|email|max:100',
            'password' => 'required|min:8',
            'role' => 'required'
        ]);

        // Vérification de la confirmation du mot de passe
        if ($data['password'] !== $data['password_confirm']) {
            $errors['password_confirm'] = 'Les mots de passe ne correspondent pas';
        }

        // Vérification de l'unicité
        if ($this->userModel->isUsernameExists($data['username'])) {
            $errors['username'] = 'Ce nom d\'utilisateur existe déjà';
        }

        if ($this->userModel->isEmailExists($data['email'])) {
            $errors['email'] = 'Cette adresse email existe déjà';
        }

        // Validation du rôle
        $allowedRoles = ['DGSN', 'DRH', 'Délégué Régional', 'Superviseur', 'Policier'];
        if (!in_array($data['role'], $allowedRoles)) {
            $errors['role'] = 'Rôle invalide';
        }

        if (!empty($errors)) {
            $this->json(['success' => false, 'errors' => $errors], 400);
            return;
        }

        // Création de l'utilisateur
        unset($data['password_confirm']);
        $user = $this->userModel->createUser($data);

        if ($user) {
            $this->logAction('user_created', ['new_user_id' => $user['id'], 'role' => $user['role']]);
            $this->json(['success' => true, 'message' => 'Utilisateur créé avec succès']);
        } else {
            $this->json(['success' => false, 'message' => 'Erreur lors de la création de l\'utilisateur'], 500);
        }
    }

    public function showForgotPassword()
    {
        $this->render('auth/forgot-password.twig');
    }

    public function forgotPassword()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/forgot-password');
        }

        $email = $this->sanitizeInput($_POST['email'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->json(['success' => false, 'message' => 'Adresse email invalide'], 400);
            return;
        }

        $user = $this->userModel->findBy('email', $email);

        if ($user) {
            // Générer un token de réinitialisation
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Sauvegarder le token (vous devrez créer une table pour cela)
            // $this->saveResetToken($user['id'], $token, $expiry);

            // Envoyer l'email de réinitialisation
            $this->sendResetEmail($email, $token);
            
            $this->logAction('password_reset_requested', ['email' => $email]);
        }

        // Toujours retourner succès pour éviter l'énumération d'emails
        $this->json(['success' => true, 'message' => 'Si cette adresse email existe, vous recevrez un lien de réinitialisation']);
    }

    public function showResetPassword($token)
    {
        // Vérifier la validité du token
        // $resetData = $this->getResetToken($token);
        
        // if (!$resetData || strtotime($resetData['expiry']) < time()) {
        //     $this->redirect('/login?error=token_expired');
        // }

        $this->render('auth/reset-password.twig', ['token' => $token]);
    }

    public function resetPassword()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/login');
        }

        $token = $_POST['token'] ?? '';
        $password = $_POST['password'] ?? '';
        $passwordConfirm = $_POST['password_confirm'] ?? '';

        if ($password !== $passwordConfirm) {
            $this->json(['success' => false, 'message' => 'Les mots de passe ne correspondent pas'], 400);
            return;
        }

        if (strlen($password) < 8) {
            $this->json(['success' => false, 'message' => 'Le mot de passe doit contenir au moins 8 caractères'], 400);
            return;
        }

        // Vérifier et utiliser le token
        // $resetData = $this->getResetToken($token);
        // if ($resetData) {
        //     $this->userModel->updatePassword($resetData['user_id'], $password);
        //     $this->deleteResetToken($token);
        //     $this->logAction('password_reset_completed', ['user_id' => $resetData['user_id']]);
        // }

        $this->json(['success' => true, 'message' => 'Mot de passe réinitialisé avec succès']);
    }

    private function createSession($user, $remember = false)
    {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['last_activity'] = time();

        // Régénérer l'ID de session pour la sécurité
        session_regenerate_id(true);

        if ($remember) {
            $token = bin2hex(random_bytes(32));
            setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/'); // 30 jours
            // Sauvegarder le token en base de données
        }
    }

    private function getRedirectUrl($role)
    {
        switch ($role) {
            case 'DGSN':
                return '/admin/dashboard';
            case 'DRH':
                return '/admin/dashboard';
            case 'Délégué Régional':
                return '/admin/dashboard';
            case 'Superviseur':
                return '/supervisor/dashboard';
            case 'Policier':
                return '/policier/dashboard';
            default:
                return '/dashboard';
        }
    }

    private function isAccountLocked($username)
    {
        $attempts = $_SESSION['login_attempts'][$username] ?? 0;
        $lastAttempt = $_SESSION['last_attempt'][$username] ?? 0;
        
        // Verrouillage après 5 tentatives pendant 15 minutes
        if ($attempts >= 5 && (time() - $lastAttempt) < 900) {
            return true;
        }

        return false;
    }

    private function incrementLoginAttempts($username)
    {
        $_SESSION['login_attempts'][$username] = ($_SESSION['login_attempts'][$username] ?? 0) + 1;
        $_SESSION['last_attempt'][$username] = time();
    }

    private function resetLoginAttempts($username)
    {
        unset($_SESSION['login_attempts'][$username]);
        unset($_SESSION['last_attempt'][$username]);
    }

    private function sendResetEmail($email, $token)
    {
        // Implémentation de l'envoi d'email
        // Utiliser PHPMailer ou une autre bibliothèque
        $resetUrl = $_ENV['APP_URL'] . "/reset-password?token=" . $token;
        
        // Code d'envoi d'email ici
    }
}


<?php

namespace App\Controllers;

use Core\Controller;
use App\Models\User;
use App\Models\Policier;
use App\Models\Demande;
use App\Models\Notification;

class DashboardController extends Controller
{
    private $userModel;
    private $policierModel;
    private $demandeModel;

    public function __construct()
    {
        parent::__construct();
        $this->requireAuth();
        $this->userModel = new User();
        $this->policierModel = new Policier();
        $this->demandeModel = new Demande();
    }

    public function index()
    {
        $userRole = $_SESSION['user_role'];
        
        switch ($userRole) {
            case 'DGSN':
            case 'DRH':
            case 'Délégué Régional':
                return $this->adminDashboard();
            case 'Superviseur':
                return $this->supervisorDashboard();
            case 'Policier':
                return $this->policierDashboard();
            default:
                $this->renderError('Rôle non reconnu', 403);
        }
    }

    private function adminDashboard()
    {
        $stats = [
            'total_policiers' => $this->policierModel->count(),
            'total_demandes' => $this->demandeModel->count(),
            'demandes_en_attente' => $this->demandeModel->count(['statut' => 'en_attente']),
            'demandes_approuvees' => $this->demandeModel->count(['statut' => 'approuvee']),
            'demandes_rejetees' => $this->demandeModel->count(['statut' => 'rejetee'])
        ];

        $recentDemandes = $this->demandeModel->getRecentDemandes(10);
        $demandesEnAttente = $this->demandeModel->getDemandesEnAttente(5);
        $statsByGrade = $this->policierModel->getStatsByGrade();
        $statsByLocalisation = $this->policierModel->getStatsByLocalisation();
        $monthlyStats = $this->demandeModel->getMonthlyStats();

        $data = [
            'stats' => $stats,
            'recent_demandes' => $recentDemandes,
            'demandes_en_attente' => $demandesEnAttente,
            'stats_by_grade' => $statsByGrade,
            'stats_by_localisation' => $statsByLocalisation,
            'monthly_stats' => $monthlyStats,
            'user_role' => $_SESSION['user_role']
        ];

        $this->render('dashboard/admin.twig', $data);
    }

    private function supervisorDashboard()
    {
        // Récupérer les informations du superviseur
        $superviseur = $this->policierModel->getByUserId($_SESSION['user_id']);
        
        if (!$superviseur) {
            $this->renderError('Profil superviseur non trouvé', 404);
            return;
        }

        // Statistiques pour la région/zone du superviseur
        $stats = [
            'policiers_zone' => $this->policierModel->count(['localisation' => $superviseur['localisation']]),
            'demandes_zone' => $this->demandeModel->count(),
            'demandes_en_attente_zone' => $this->demandeModel->count(['statut' => 'en_attente'])
        ];

        $recentDemandes = $this->demandeModel->getRecentDemandes(10);
        $demandesEnAttente = $this->demandeModel->getDemandesEnAttente(5);

        $data = [
            'stats' => $stats,
            'recent_demandes' => $recentDemandes,
            'demandes_en_attente' => $demandesEnAttente,
            'superviseur' => $superviseur,
            'user_role' => $_SESSION['user_role']
        ];

        $this->render('dashboard/supervisor.twig', $data);
    }

    private function policierDashboard()
    {
        // Récupérer les informations du policier
        $policier = $this->policierModel->getByUserId($_SESSION['user_id']);
        
        if (!$policier) {
            $this->renderError('Profil policier non trouvé', 404);
            return;
        }

        // Statistiques personnelles
        $stats = [
            'mes_demandes' => $this->demandeModel->count(['policier_id' => $policier['id']]),
            'demandes_en_attente' => $this->demandeModel->count([
                'policier_id' => $policier['id'],
                'statut' => 'en_attente'
            ]),
            'demandes_approuvees' => $this->demandeModel->count([
                'policier_id' => $policier['id'],
                'statut' => 'approuvee'
            ]),
            'demandes_rejetees' => $this->demandeModel->count([
                'policier_id' => $policier['id'],
                'statut' => 'rejetee'
            ])
        ];

        $mesDemandes = $this->demandeModel->getByPolicier($policier['id']);
        $notifications = $this->getNotifications($_SESSION['user_id'], 5);

        $data = [
            'stats' => $stats,
            'mes_demandes' => $mesDemandes,
            'notifications' => $notifications,
            'policier' => $policier,
            'user_role' => $_SESSION['user_role']
        ];

        $this->render('dashboard/policier.twig', $data);
    }

    public function getStats()
    {
        $this->requireRole(['DGSN', 'DRH', 'Délégué Régional']);

        $type = $_GET['type'] ?? 'general';
        $period = $_GET['period'] ?? 'month';

        switch ($type) {
            case 'demandes':
                $stats = $this->getDemandesStats($period);
                break;
            case 'personnel':
                $stats = $this->getPersonnelStats();
                break;
            case 'localisation':
                $stats = $this->getLocalisationStats();
                break;
            default:
                $stats = $this->getGeneralStats();
        }

        $this->json(['success' => true, 'data' => $stats]);
    }

    public function getNotifications($userId = null, $limit = 10)
    {
        $userId = $userId ?? $_SESSION['user_id'];
        
        // Simulation des notifications (vous devrez implémenter le modèle Notification)
        $notifications = [
            [
                'id' => 1,
                'message' => 'Nouvelle demande de congé en attente',
                'type' => 'demande',
                'lue' => false,
                'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))
            ],
            [
                'id' => 2,
                'message' => 'Votre demande de mutation a été approuvée',
                'type' => 'approbation',
                'lue' => false,
                'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))
            ]
        ];

        return array_slice($notifications, 0, $limit);
    }

    public function markNotificationAsRead()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['success' => false, 'message' => 'Méthode non autorisée'], 405);
            return;
        }

        $notificationId = $_POST['notification_id'] ?? null;

        if (!$notificationId) {
            $this->json(['success' => false, 'message' => 'ID de notification requis'], 400);
            return;
        }

        // Marquer la notification comme lue
        // $this->notificationModel->markAsRead($notificationId, $_SESSION['user_id']);

        $this->json(['success' => true, 'message' => 'Notification marquée comme lue']);
    }

    private function getDemandesStats($period)
    {
        $year = date('Y');
        $monthlyStats = $this->demandeModel->getMonthlyStats($year);
        $statsByType = $this->demandeModel->getStatsByType();
        $statsByStatut = $this->demandeModel->getStatsByStatut();

        return [
            'monthly' => $monthlyStats,
            'by_type' => $statsByType,
            'by_status' => $statsByStatut
        ];
    }

    private function getPersonnelStats()
    {
        return [
            'by_grade' => $this->policierModel->getStatsByGrade(),
            'by_localisation' => $this->policierModel->getStatsByLocalisation(),
            'by_poste' => $this->policierModel->getStatsByPoste(),
            'by_sexe' => $this->policierModel->getStatsBySexe(),
            'by_age' => $this->policierModel->getAgeStats()
        ];
    }

    private function getLocalisationStats()
    {
        return [
            'personnel' => $this->policierModel->getStatsByLocalisation(),
            'demandes' => $this->demandeModel->getDemandesByLocalisation()
        ];
    }

    private function getGeneralStats()
    {
        return [
            'total_users' => $this->userModel->count(),
            'total_policiers' => $this->policierModel->count(),
            'total_demandes' => $this->demandeModel->count(),
            'users_by_role' => $this->userModel->getUserStats(),
            'recent_activity' => $this->getRecentActivity()
        ];
    }

    private function getRecentActivity()
    {
        // Récupérer l'activité récente depuis les logs
        $sql = "SELECT l.*, u.username 
                FROM logs l 
                LEFT JOIN utilisateurs u ON l.user_id = u.id 
                ORDER BY l.created_at DESC 
                LIMIT 10";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function exportStats()
    {
        $this->requireRole(['DGSN', 'DRH']);

        $format = $_GET['format'] ?? 'pdf';
        $type = $_GET['type'] ?? 'general';

        switch ($format) {
            case 'pdf':
                $this->exportToPDF($type);
                break;
            case 'excel':
                $this->exportToExcel($type);
                break;
            case 'csv':
                $this->exportToCSV($type);
                break;
            default:
                $this->json(['success' => false, 'message' => 'Format non supporté'], 400);
        }
    }

    private function exportToPDF($type)
    {
        // Implémentation de l'export PDF avec DOMPDF
        require_once __DIR__ . '/../../vendor/autoload.php';
        
        $dompdf = new \Dompdf\Dompdf();
        
        $html = $this->generateReportHTML($type);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        
        $filename = "rapport_" . $type . "_" . date('Y-m-d') . ".pdf";
        $dompdf->stream($filename, ['Attachment' => true]);
    }

    private function exportToExcel($type)
    {
        // Implémentation de l'export Excel avec PhpSpreadsheet
        require_once __DIR__ . '/../../vendor/autoload.php';
        
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        
        // Ajouter les données selon le type
        $this->populateExcelSheet($sheet, $type);
        
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        
        $filename = "rapport_" . $type . "_" . date('Y-m-d') . ".xlsx";
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        
        $writer->save('php://output');
    }

    private function exportToCSV($type)
    {
        $filename = "rapport_" . $type . "_" . date('Y-m-d') . ".csv";
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // Ajouter les données selon le type
        $this->populateCSV($output, $type);
        
        fclose($output);
    }

    private function generateReportHTML($type)
    {
        // Générer le HTML pour le rapport PDF
        $data = $this->getStatsForReport($type);
        
        return $this->twig->render('reports/pdf_template.twig', [
            'type' => $type,
            'data' => $data,
            'generated_at' => date('d/m/Y H:i:s')
        ]);
    }

    private function populateExcelSheet($sheet, $type)
    {
        // Remplir la feuille Excel selon le type de rapport
        $data = $this->getStatsForReport($type);
        
        $sheet->setCellValue('A1', 'Rapport ' . ucfirst($type));
        $sheet->setCellValue('A2', 'Généré le ' . date('d/m/Y H:i:s'));
        
        // Ajouter les données spécifiques selon le type
    }

    private function populateCSV($output, $type)
    {
        // Remplir le CSV selon le type de rapport
        $data = $this->getStatsForReport($type);
        
        fputcsv($output, ['Rapport ' . ucfirst($type)]);
        fputcsv($output, ['Généré le ' . date('d/m/Y H:i:s')]);
        fputcsv($output, []);
        
        // Ajouter les données spécifiques selon le type
    }

    private function getStatsForReport($type)
    {
        switch ($type) {
            case 'demandes':
                return $this->getDemandesStats('year');
            case 'personnel':
                return $this->getPersonnelStats();
            case 'localisation':
                return $this->getLocalisationStats();
            default:
                return $this->getGeneralStats();
        }
    }
}


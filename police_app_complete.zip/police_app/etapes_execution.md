# Guide d'Exécution Détaillé - Application de Gestion du Personnel Police Camerounaise

## 1. Prérequis Système

### 1.1 Configuration Minimale Requise
- **Système d'exploitation** : Windows 10 (64-bit)
- **RAM** : 4 GB minimum, 8 GB recommandé
- **Espace disque** : 2 GB d'espace libre
- **Processeur** : Intel Core i3 ou équivalent AMD
- **Connexion internet** : Requise pour l'installation et les mises à jour

### 1.2 Logiciels Requis
- **XAMPP 8.2.x** ou supérieur (inclut Apache, MySQL, PHP)
- **Navigateur web moderne** : Chrome, Firefox, Edge (dernières versions)
- **Éditeur de code** (optionnel) : VS Code, Sublime Text, ou Notepad++

## 2. Installation de l'Environnement de Développement

### 2.1 Installation de XAMPP

1. **Téléchargement**
   - Rendez-vous sur https://www.apachefriends.org/
   - Téléchargez XAMPP pour Windows (version 8.2.x)
   - Taille approximative : 150 MB

2. **Installation**
   ```
   1. Exécutez le fichier xampp-windows-x64-8.2.x-installer.exe
   2. Choisissez le répertoire d'installation (par défaut : C:\xampp)
   3. Sélectionnez les composants :
      ✓ Apache
      ✓ MySQL
      ✓ PHP
      ✓ phpMyAdmin
      ✓ Perl (optionnel)
   4. Cliquez sur "Install"
   5. Attendez la fin de l'installation (5-10 minutes)
   ```

3. **Configuration initiale**
   ```
   1. Lancez XAMPP Control Panel
   2. Démarrez Apache (port 80, 443)
   3. Démarrez MySQL (port 3306)
   4. Vérifiez que les services sont "Running" (vert)
   ```

### 2.2 Vérification de l'Installation

1. **Test Apache**
   - Ouvrez votre navigateur
   - Allez sur http://localhost
   - Vous devriez voir la page d'accueil XAMPP

2. **Test MySQL**
   - Allez sur http://localhost/phpmyadmin
   - Connectez-vous (utilisateur : root, mot de passe : vide par défaut)

## 3. Installation de l'Application

### 3.1 Décompression du Projet

1. **Extraction**
   ```
   1. Téléchargez le fichier police_app.zip
   2. Extrayez le contenu dans C:\xampp\htdocs\
   3. Le dossier final doit être : C:\xampp\htdocs\police_app\
   ```

2. **Structure des fichiers**
   ```
   C:\xampp\htdocs\police_app\
   ├── app/
   │   ├── controllers/
   │   ├── models/
   │   ├── views/
   │   ├── config/
   │   └── core/
   ├── public/
   │   ├── css/
   │   ├── js/
   │   ├── img/
   │   └── index.php
   ├── vendor/
   ├── docs/
   ├── .env.example
   ├── composer.json
   └── database.sql
   ```

### 3.2 Installation des Dépendances

1. **Installation de Composer** (si pas déjà installé)
   ```
   1. Téléchargez Composer depuis https://getcomposer.org/
   2. Exécutez Composer-Setup.exe
   3. Suivez l'assistant d'installation
   4. Redémarrez votre invite de commande
   ```

2. **Installation des dépendances PHP**
   ```
   1. Ouvrez l'invite de commande (cmd)
   2. Naviguez vers le dossier du projet :
      cd C:\xampp\htdocs\police_app
   3. Exécutez :
      composer install
   4. Attendez la fin du téléchargement (5-10 minutes)
   ```

3. **Installation de Node.js et npm** (pour les dépendances frontend)
   ```
   1. Téléchargez Node.js depuis https://nodejs.org/
   2. Installez la version LTS
   3. Vérifiez l'installation :
      node --version
      npm --version
   4. Dans le dossier du projet :
      npm install
   ```

### 3.3 Configuration de la Base de Données

1. **Création de la base de données**
   ```
   1. Ouvrez phpMyAdmin (http://localhost/phpmyadmin)
   2. Cliquez sur "Nouvelle base de données"
   3. Nom : police_db
   4. Interclassement : utf8mb4_general_ci
   5. Cliquez sur "Créer"
   ```

2. **Import du schéma**
   ```
   1. Sélectionnez la base "police_db"
   2. Cliquez sur l'onglet "Importer"
   3. Choisissez le fichier "database.sql"
   4. Cliquez sur "Exécuter"
   5. Vérifiez que les tables sont créées
   ```

3. **Configuration de la connexion**
   ```
   1. Copiez .env.example vers .env
   2. Modifiez les paramètres de base de données :
      DB_HOST=localhost
      DB_NAME=police_db
      DB_USER=root
      DB_PASS=
      DB_PORT=3306
   ```

## 4. Configuration de l'Application

### 4.1 Configuration des Variables d'Environnement

1. **Fichier .env**
   ```
   # Base de données
   DB_HOST=localhost
   DB_NAME=police_db
   DB_USER=root
   DB_PASS=
   
   # Application
   APP_NAME="Gestion Personnel Police Camerounaise"
   APP_ENV=development
   APP_DEBUG=true
   APP_URL=http://localhost/police_app
   APP_KEY=votre-cle-secrete-ici
   
   # Email (configurez selon votre fournisseur)
   MAIL_HOST=smtp.gmail.com
   MAIL_PORT=587
   MAIL_USERNAME=votre-email@gmail.com
   MAIL_PASSWORD=votre-mot-de-passe-app
   
   # Sécurité
   JWT_SECRET=votre-jwt-secret
   CSRF_TOKEN_EXPIRE=3600
   ```

### 4.2 Configuration Apache

1. **Fichier .htaccess** (dans le dossier public/)
   ```apache
   RewriteEngine On
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   RewriteRule ^(.*)$ index.php [QSA,L]
   
   # Sécurité
   Header always set X-Content-Type-Options nosniff
   Header always set X-Frame-Options DENY
   Header always set X-XSS-Protection "1; mode=block"
   
   # Cache
   <IfModule mod_expires.c>
       ExpiresActive On
       ExpiresByType text/css "access plus 1 month"
       ExpiresByType application/javascript "access plus 1 month"
       ExpiresByType image/png "access plus 1 month"
       ExpiresByType image/jpg "access plus 1 month"
       ExpiresByType image/jpeg "access plus 1 month"
   </IfModule>
   ```

### 4.3 Permissions des Dossiers

1. **Dossiers en écriture**
   ```
   - public/uploads/ (777)
   - logs/ (777)
   - cache/ (777)
   ```

2. **Configuration Windows**
   ```
   1. Clic droit sur chaque dossier
   2. Propriétés > Sécurité
   3. Modifier > Ajouter "Tout le monde"
   4. Cocher "Contrôle total"
   ```

## 5. Première Exécution

### 5.1 Démarrage des Services

1. **XAMPP Control Panel**
   ```
   1. Lancez XAMPP Control Panel en tant qu'administrateur
   2. Démarrez Apache
   3. Démarrez MySQL
   4. Vérifiez que les deux services sont verts
   ```

2. **Vérification des ports**
   ```
   - Apache : 80, 443
   - MySQL : 3306
   - En cas de conflit, modifiez les ports dans XAMPP
   ```

### 5.2 Accès à l'Application

1. **URL d'accès**
   ```
   http://localhost/police_app/public/
   ```

2. **Comptes de test**
   ```
   Super Administrateur (DGSN) :
   - Username : dgsn_admin
   - Password : password123
   
   Administrateur DRH :
   - Username : drh_admin
   - Password : password123
   
   Policier :
   - Username : policier_1
   - Password : password123
   ```

### 5.3 Vérification du Fonctionnement

1. **Tests de base**
   ```
   ✓ Page de connexion s'affiche
   ✓ Connexion avec les comptes de test
   ✓ Tableau de bord accessible
   ✓ Navigation entre les pages
   ✓ Déconnexion fonctionne
   ```

2. **Tests avancés**
   ```
   ✓ Création d'un nouveau policier
   ✓ Soumission d'une demande
   ✓ Upload d'un fichier
   ✓ Génération d'un rapport PDF
   ✓ Notifications en temps réel
   ```

## 6. Configuration Avancée

### 6.1 Configuration Email

1. **Gmail SMTP**
   ```
   1. Activez l'authentification à 2 facteurs sur Gmail
   2. Générez un mot de passe d'application
   3. Utilisez ce mot de passe dans .env
   
   MAIL_HOST=smtp.gmail.com
   MAIL_PORT=587
   MAIL_USERNAME=votre-email@gmail.com
   MAIL_PASSWORD=mot-de-passe-app
   MAIL_ENCRYPTION=tls
   ```

2. **Test d'envoi**
   ```
   1. Allez dans l'interface admin
   2. Testez l'envoi de notification
   3. Vérifiez la réception de l'email
   ```

### 6.2 Configuration SSL (Optionnel)

1. **Certificat auto-signé**
   ```
   1. Dans XAMPP, activez SSL pour Apache
   2. Accédez via https://localhost/police_app/public/
   3. Acceptez le certificat auto-signé
   ```

### 6.3 Optimisation des Performances

1. **Cache PHP**
   ```
   1. Activez OPcache dans php.ini
   2. Configurez les paramètres de cache
   3. Redémarrez Apache
   ```

2. **Compression**
   ```
   1. Activez mod_deflate dans Apache
   2. Configurez la compression gzip
   3. Testez avec les outils de développement
   ```

## 7. Maintenance et Sauvegarde

### 7.1 Sauvegarde de la Base de Données

1. **Sauvegarde manuelle**
   ```
   1. phpMyAdmin > police_db > Exporter
   2. Format : SQL
   3. Téléchargez le fichier .sql
   ```

2. **Sauvegarde automatique** (script batch)
   ```batch
   @echo off
   set date=%date:~-4,4%%date:~-10,2%%date:~-7,2%
   "C:\xampp\mysql\bin\mysqldump" -u root police_db > "backup_%date%.sql"
   ```

### 7.2 Mise à Jour de l'Application

1. **Sauvegarde avant mise à jour**
   ```
   1. Sauvegardez la base de données
   2. Copiez le dossier de l'application
   3. Notez les modifications dans .env
   ```

2. **Procédure de mise à jour**
   ```
   1. Remplacez les fichiers de l'application
   2. Exécutez : composer update
   3. Exécutez : npm update
   4. Importez les nouvelles migrations SQL
   5. Testez l'application
   ```

## 8. Déploiement sur Serveur Distant

### 8.1 Préparation pour la Production

1. **Configuration de production**
   ```
   APP_ENV=production
   APP_DEBUG=false
   
   # Utilisez des mots de passe forts
   DB_PASS=mot-de-passe-fort
   JWT_SECRET=cle-jwt-complexe
   ```

2. **Optimisations**
   ```
   1. Minifiez CSS et JavaScript
   2. Optimisez les images
   3. Configurez le cache
   4. Activez la compression
   ```

### 8.2 Upload sur Serveur

1. **Via FTP/SFTP**
   ```
   1. Uploadez tous les fichiers sauf .env
   2. Créez .env sur le serveur avec les bonnes valeurs
   3. Configurez les permissions des dossiers
   ```

2. **Configuration serveur**
   ```
   1. Pointez le domaine vers /public/
   2. Configurez SSL avec Let's Encrypt
   3. Configurez les sauvegardes automatiques
   ```

## 9. Dépannage

### 9.1 Problèmes Courants

1. **Apache ne démarre pas**
   ```
   - Vérifiez que le port 80 n'est pas utilisé
   - Désactivez IIS si installé
   - Vérifiez les logs Apache
   ```

2. **Erreur de connexion MySQL**
   ```
   - Vérifiez que MySQL est démarré
   - Contrôlez les paramètres dans .env
   - Testez la connexion dans phpMyAdmin
   ```

3. **Page blanche**
   ```
   - Activez l'affichage des erreurs PHP
   - Vérifiez les logs d'erreur
   - Contrôlez les permissions des fichiers
   ```

### 9.2 Logs et Débogage

1. **Logs Apache**
   ```
   C:\xampp\apache\logs\error.log
   ```

2. **Logs MySQL**
   ```
   C:\xampp\mysql\data\mysql_error.log
   ```

3. **Logs de l'application**
   ```
   police_app/logs/app.log
   ```

## 10. Support et Documentation

### 10.1 Documentation Technique

- **API Documentation** : /docs/api.html
- **Guide Utilisateur** : /docs/user-guide.pdf
- **Guide Administrateur** : /docs/admin-guide.pdf

### 10.2 Ressources Supplémentaires

- **Forum XAMPP** : https://community.apachefriends.org/
- **Documentation PHP** : https://www.php.net/docs.php
- **Documentation MySQL** : https://dev.mysql.com/doc/

### 10.3 Contact Support

Pour toute assistance technique :
- Email : support@police-app.cm
- Téléphone : +237 XXX XXX XXX
- Documentation en ligne : https://docs.police-app.cm


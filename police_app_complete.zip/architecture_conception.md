# Architecture de l'Application de Gestion du Personnel de la Police Camerounaise

## 1. Introduction

Ce document décrit l'architecture technique de l'application web et mobile pour la gestion du personnel de la Police camerounaise. L'objectif est de construire une application robuste, sécurisée, et maintenable en utilisant les technologies modernes.

## 2. Besoins Fonctionnels

L'application doit répondre aux besoins suivants :

*   **Authentification sécurisée multi-administrateurs** avec gestion des rôles (DGSN, DRH, Délégués régionaux, Superviseurs, etc.).
*   **Interface utilisateur pour chaque policier** pour la connexion, la demande de carte professionnelle, le suivi des demandes, la consultation du dossier personnel, la réception de notifications, le téléchargement de documents, l'impression du récapitulatif de carrière, et la gestion du profil.
*   **Interface d'administration** pour la gestion du personnel, la production des cartes professionnelles, la gestion des carrières, la réponse aux demandes, et la génération de statistiques.
*   **Interface Super Administrateur (DGSN)** avec accès complet, gestion des administrateurs, statistiques globales, configuration système, et sauvegarde/restauration des données.
*   **Tableau de bord dynamique** avec des statistiques et des graphiques.
*   **Système de notifications** par e-mail et sur le tableau de bord.
*   **Recherche filtrée** avancée.
*   **Prise en charge multi-utilisateurs** avec des sessions sécurisées.
*   **Interactions dynamiques** sans rechargement de page grâce à AJAX et jQuery.
*   **Base de données MySQL** pour le stockage des données.
*   **Composants front-end dynamiques** avec Angular.
*   **Design responsive** pour une utilisation sur le web et les mobiles.
*   **Sécurité renforcée** avec ReCaptcha, validation des champs, journalisation des actions, hashage des mots de passe, et protection contre les attaques CSRF, XSS, et injections SQL.

## 3. Architecture MVC (Modèle-Vue-Contrôleur)

L'application sera basée sur une architecture MVC claire pour séparer la logique métier, la présentation, et le contrôle des requêtes.

*   **Modèle (Model)** : Gère les données et la logique métier. Interagit avec la base de données MySQL. Les modèles seront des classes PHP responsables des opérations CRUD (Create, Read, Update, Delete) sur les données.
*   **Vue (View)** : Responsable de la présentation des données à l'utilisateur. Les vues seront des fichiers HTML/PHP contenant le code de l'interface utilisateur, y compris les éléments Bootstrap et Angular.
*   **Contrôleur (Controller)** : Gère les requêtes de l'utilisateur, interagit avec les modèles pour récupérer les données, et sélectionne la vue appropriée pour afficher la réponse.

## 4. Rôles et Permissions

Un système de rôles et de permissions sera mis en place pour contrôler l'accès aux fonctionnalités de l'application.

| Rôle | Permissions |
| --- | --- |
| DGSN (Super Administrateur) | Accès complet à toutes les fonctionnalités, y compris la gestion des administrateurs et la configuration du système. |
| DRH | Gestion complète du personnel, des carrières, des formations, et des demandes. |
| Délégué Régional | Gestion du personnel et des demandes au niveau de sa région. |
| Superviseur | Consultation des dossiers et suivi des demandes pour son équipe. |
| Policier | Accès à son dossier personnel, création et suivi de ses demandes. |

## 5. Sécurité

La sécurité est une priorité absolue pour cette application. Les mesures suivantes seront mises en œuvre :

*   **Hashage des mots de passe** avec l'algorithme bcrypt.
*   **Protection contre les injections SQL** en utilisant des requêtes préparées (prepared statements).
*   **Protection contre les attaques XSS (Cross-Site Scripting)** en échappant toutes les données affichées dans les vues.
*   **Protection contre les attaques CSRF (Cross-Site Request Forgery)** en utilisant des jetons (tokens) CSRF.
*   **Sessions sécurisées** avec des identifiants de session uniques et une expiration régulière.
*   **Validation des données** côté client (JavaScript) et côté serveur (PHP).
*   **Journalisation des actions sensibles** pour un audit de sécurité.
*   **ReCaptcha** sur le formulaire d'inscription pour prévenir les bots.

## 6. Architecture de la Base de Données

La base de données MySQL sera conçue pour stocker toutes les informations de manière structurée et efficace. Les tables principales incluront :

*   `utilisateurs` : Informations de connexion et rôles.
*   `policiers` : Dossiers personnels des policiers.
*   `demandes` : Toutes les demandes des policiers (affectation, mutation, etc.).
*   `cartes_professionnelles` : Suivi de la production des cartes.
*   `notifications` : Notifications pour les utilisateurs.
*   `logs` : Journal des actions.

## 7. Technologies et Frameworks

*   **Backend** : PHP 8.x
*   **Base de données** : MySQL 8.x
*   **Frontend** : HTML5, CSS3, JavaScript, jQuery, Bootstrap 5, Angular 15
*   **Serveur web** : Apache (via XAMPP)
*   **Dépendances PHP** : Composer pour la gestion des dépendances.
*   **Dépendances JavaScript** : npm ou yarn pour la gestion des dépendances.




## 8. Environnement de Développement

L'environnement de développement recommandé est XAMPP sur Windows 10, qui fournit Apache, MySQL, PHP et Perl dans un package facile à installer. Cela permettra un déploiement local rapide et une transition aisée vers un serveur distant.

## 9. Structure du Projet (Exemple)

```
police_app/
├── app/
│   ├── controllers/
│   ├── models/
│   ├── views/
│   ├── config/
│   ├── core/
│   └── public/
│       ├── css/
│       ├── js/
│       ├── img/
│       └── index.php
├── vendor/
├── node_modules/
├── .htaccess
├── composer.json
├── package.json
└── README.md
```

## 10. Flux de Données et Interactions

1.  **Requête Utilisateur** : L'utilisateur accède à l'application via son navigateur web ou mobile.
2.  **Routage** : Le serveur web (Apache) redirige la requête vers le contrôleur approprié via le fichier `index.php` et le système de routage.
3.  **Contrôleur** : Le contrôleur reçoit la requête, valide les données, interagit avec un ou plusieurs modèles pour récupérer ou manipuler les données.
4.  **Modèle** : Le modèle interagit avec la base de données MySQL pour effectuer les opérations nécessaires.
5.  **Vue** : Le contrôleur passe les données au modèle de vue (si nécessaire), qui prépare la vue à afficher. Les vues utilisent Bootstrap pour le responsive design et Angular pour les composants dynamiques.
6.  **Réponse** : La vue génère la réponse HTML/CSS/JavaScript qui est renvoyée au navigateur de l'utilisateur.
7.  **Interactions AJAX/jQuery** : Pour les interactions dynamiques (ex: recherche filtrée, notifications en temps réel), des requêtes AJAX sont envoyées au backend, qui renvoie des données JSON. jQuery est utilisé pour manipuler le DOM et afficher ces données sans rechargement complet de la page.

## 11. Planification de la Sécurité

En plus des mesures de sécurité mentionnées précédemment, une attention particulière sera portée à :

*   **Gestion des sessions** : Utilisation de sessions PHP sécurisées, régénération de l'ID de session après connexion, et expiration des sessions inactives.
*   **Protection contre les attaques par force brute** : Limitation des tentatives de connexion.
*   **Journalisation des événements de sécurité** : Enregistrement des tentatives de connexion échouées, des accès non autorisés, et des modifications critiques.
*   **Mises à jour régulières** : Maintenir PHP, MySQL, Apache, et toutes les bibliothèques tierces à jour pour bénéficier des dernières corrections de sécurité.

## 12. Conclusion de la Phase d'Analyse et de Conception

Cette phase a permis de définir les bases solides de l'application, en détaillant les besoins, l'architecture, les technologies, et les mesures de sécurité. La prochaine étape consistera à implémenter la structure de la base de données MySQL, en se basant sur les entités identifiées et leurs relations.


CREATE DATABASE IF NOT EXISTS `police_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `police_db`;

-- Table pour les utilisateurs et l'authentification
CREATE TABLE `utilisateurs` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `role` ENUM('DGSN', 'DRH', 'Délégué Régional', 'Superviseur', 'Policier') NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table pour les informations personnelles des policiers
CREATE TABLE `policiers` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `nom` VARCHAR(100) NOT NULL,
  `prenom` VARCHAR(100) NOT NULL,
  `matricule` VARCHAR(20) NOT NULL UNIQUE,
  `grade` VARCHAR(50) NOT NULL,
  `poste` VARCHAR(100) NOT NULL,
  `localisation` VARCHAR(100) NOT NULL,
  `date_naissance` DATE NOT NULL,
  `lieu_naissance` VARCHAR(100) NOT NULL,
  `sexe` ENUM('Homme', 'Femme') NOT NULL,
  `telephone` VARCHAR(20) NOT NULL,
  `adresse` TEXT NOT NULL,
  `photo` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `utilisateurs`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table pour les demandes des policiers
CREATE TABLE `demandes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `policier_id` INT(11) NOT NULL,
  `type_demande` ENUM('affectation', 'mutation', 'promotion', 'conge', 'formation', 'sanction', 'notation') NOT NULL,
  `description` TEXT NOT NULL,
  `statut` ENUM('en_attente', 'approuvee', 'rejetee') NOT NULL DEFAULT 'en_attente',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`policier_id`) REFERENCES `policiers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table pour la production des cartes professionnelles
CREATE TABLE `cartes_professionnelles` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `policier_id` INT(11) NOT NULL,
  `numero_carte` VARCHAR(50) NOT NULL UNIQUE,
  `date_emission` DATE NOT NULL,
  `date_expiration` DATE NOT NULL,
  `statut` ENUM('en_cours', 'produite', 'delivree') NOT NULL DEFAULT 'en_cours',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`policier_id`) REFERENCES `policiers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table pour les notifications
CREATE TABLE `notifications` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `message` TEXT NOT NULL,
  `lue` BOOLEAN NOT NULL DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `utilisateurs`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table pour la journalisation des actions
CREATE TABLE `logs` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) DEFAULT NULL,
  `action` VARCHAR(255) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




-- Données de test pour la table `utilisateurs`
INSERT INTO `utilisateurs` (`username`, `password`, `email`, `role`) VALUES
("dgsn_admin", "$2y$10$Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q", "dgsn@police.cm", "DGSN"), -- Mot de passe: password123
("drh_admin", "$2y$10$Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q", "drh@police.cm", "DRH"), -- Mot de passe: password123
("policier_1", "$2y$10$Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q", "policier1@police.cm", "Policier"); -- Mot de passe: password123

-- Données de test pour la table `policiers`
INSERT INTO `policiers` (`user_id`, `nom`, `prenom`, `matricule`, `grade`, `poste`, `localisation`, `date_naissance`, `lieu_naissance`, `sexe`, `telephone`, `adresse`)
SELECT u.id, 'Dupont', 'Jean', 'P-001', 'Inspecteur', 'Enquêteur', 'Yaoundé', '1985-05-10', 'Douala', 'Homme', '677123456', 'Rue de la Paix, Yaoundé' FROM utilisateurs u WHERE u.username = 'policier_1';

-- Données de test pour la table `demandes`
INSERT INTO `demandes` (`policier_id`, `type_demande`, `description`, `statut`)
SELECT p.id, 'conge', 'Demande de congé annuel du 1er au 15 août', 'en_attente' FROM policiers p WHERE p.matricule = 'P-001';

-- Données de test pour la table `cartes_professionnelles`
INSERT INTO `cartes_professionnelles` (`policier_id`, `numero_carte`, `date_emission`, `date_expiration`, `statut`)
SELECT p.id, 'CP-001-2025', '2025-01-01', '2030-01-01', 'produite' FROM policiers p WHERE p.matricule = 'P-001';


